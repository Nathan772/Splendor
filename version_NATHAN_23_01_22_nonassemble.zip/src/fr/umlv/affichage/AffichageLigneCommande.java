package fr.umlv.affichage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Scanner;
import java.awt.Color;
import java.lang.StringBuilder;

import fr.umlv.game.Partie;
import fr.umlv.game.mode.*;
import fr.umlv.players.*;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;


/**
 * Declaration of the class AffichageLigneCommande. It gathers all the functions thah print objets on
 * the console
 * 
 * @author dylandejesus nathanbilingi
 */
public class AffichageLigneCommande implements Affichage{
	
	
	public void launchAffichage() {
		Partie.startGame(this);
	}
	
	
	/**
	 * Print the game board of a game.
	 * 
	 * @param game
	 *        Game to print its board
	 * 
	 * @param mode
	 *        Game mode
	 */
	public void showPlateau(Mode game, int mode) {
		
		Objects.requireNonNull(game);
		
		if(mode != 1) {
			showTuiles(game);
		}
		
		showBoard(game);
		showJeton(game.jetons_disponibles(), null, "JETON");
		
		System.out.println("\n\n========================================== JOUEURS ==========================================\n\n");
		
		for(var joueur : game.joueurs()) {
			showJoueur(joueur);
			System.out.println("\n");
		}	
	}
	
	
	public int recupMode() {
		return recupTouche();
	}

	public int recupParticipants() {
		return recupTouche();
	}
	
	
	public int recupTouche() throws IllegalArgumentException{	/*On fera plutôt passer un scanner*/
		
		Scanner scanner = new Scanner(System.in);
		
		var scan = new Scanner(System.in);
		
		
		return scan.nextInt();
	}
	
	
	public void affichageMessageInstructionsBox(String message) {
		affichageMessage(message, 0);
		
	}
	
	public void affichageMessageActions(String message) {
		affichageMessage(message, 0);
		
	}
	
	
	
	public void affichageMessage(String message, int nb_choices) {
		System.out.println(message);
	}
	/**
	 * 
	 * 
	 * @param banque
	 * the tokens that one wants to display
	 * @param chaine_tab
	 * a Builder that will be necessary to show the table
	 * @param chaine_noms
	 * a Builder that will be necessary to show the tokens names
	 * @param chaine_quantite
	 * the quantity of a specific token
	 */
	private void showBanqueOrRessources(HashMap<String, Integer> banque,StringBuilder chaine_tab, StringBuilder chaine_noms, StringBuilder chaine_quantite) {
		//20 lignes exactement
		String separator = "|    ";
		String separator_quantite = "|      ";
		if(banque != null) {
			for(var entry : banque.entrySet()) {
				
				var jeton_name = entry.getKey();
				
				if(jeton_name.equals("Vert") || jeton_name.equals("Noir") || jeton_name.equals("Bleu")) {
					jeton_name = jeton_name + " ";
				}
				var jeton_quantite = entry.getValue();
				
			
				 chaine_noms.append(separator).append(jeton_name);
				 chaine_quantite.append(separator_quantite).append(jeton_quantite);
				 
				 separator = "    |    ";
				 separator_quantite = "      |      ";
			}
		}
		System.out.println(chaine_tab);
		System.out.println(chaine_noms);
		System.out.println(chaine_tab);
		System.out.println(chaine_quantite);
		System.out.println(chaine_tab);
		
	}
	/**
	 * 
	 * Print the available tokens on the console. It is represented as a board.
	 * 
	 * @param ressources
	 *        Resources of tokens
	 */
	//25 lignes : trop long
	public void showJeton(HashMap<String, Integer> banque, HashMap<String, Integer> ressources, String message) {
		
		StringBuilder chaine_tab = new StringBuilder();
		StringBuilder chaine_noms = new StringBuilder();
		StringBuilder chaine_quantite = new StringBuilder();
		
		
		if(message != null) {
			System.out.println("\n\n========================================== "+ message + " ==========================================\n\n");
		}
		if(banque != null) {
			showBanqueOrRessources(banque,chaine_tab,chaine_noms, chaine_quantite);
			
		}
		
		if(ressources != null) {
			StringBuilder chaine_tab2 = new StringBuilder();
			StringBuilder chaine_noms2 = new StringBuilder();
			StringBuilder chaine_quantite2 = new StringBuilder();
			showBanqueOrRessources(ressources,chaine_tab2,chaine_noms2, chaine_quantite2);
		}
	}

	
	/**
	 * Print the cards of the board of the game token.
	 * 
	 * @param game
	 *        Game token to print it board
	 */
	public void showBoard(Mode game) {
		
		Objects.requireNonNull(game);
		
		for(int i = 1 ; i < game.board().size() + 1 ; i++) {
			
			var num_card = 1;
			
			if(game.board().get(i).get(0) != null) {
				
				System.out.println("\n\n    -- NIVEAU " + i + " --\n\n");
				
				for(var carte : game.board().get(i)) {
					
					System.out.println("\n      Carte n° " + num_card + "\n");
					
					if(carte != null)
						System.out.println(carte);
					num_card ++;	
				}
			}
		}
	}
	
	/**
	 * Print the player informations.
	 * 
	 * @param joueur
	 * 	      Player given to show its game infomations 
	 */
	public int showJoueur(Participant joueur) {
		
		System.out.println("Joueur : " + joueur.pseudo() + "\n\nPoints de prestiges : " + joueur.points_prestiges() + "\n\nRessources : \n");
		System.out.println("Joueur :  " + "\n");
		showJeton(joueur.ressources(), null, "JETON");
		showJeton(joueur.bonus(), null, "BONUS");
		this.showReserved(joueur);
		return 0;
	}
	
	/**
	 * Print the Nobles Cards on the board.
	 * 
	 * @param game
	 *        Game given to show its nobles card on the board
	 */
	public void showTuiles(Mode game){
		
		System.out.println("    -- NOBLES --   \n\n");
		
		for(int i = 0 ; i < game.tuiles_board().size(); i++) {
			
			System.out.println(game.tuiles_board().get(i));
		}
	}
	
	
	/**
	 * Print the cards reserved by a player.
	 * 
	 * @param joueur
	 * 		  Player given.
	 */
	public void showReserved(Participant joueur) {
		
		Objects.requireNonNull(joueur);
		
		if(joueur.reserve().size() == 0) {
			System.out.println("Vous ne possèdez aucune carte réservée \n\n");
			return;
		}
		
		System.out.println("Cartes que vous avez réservé \n\n");
		
		for(var elem : joueur.reserve()) {
			System.out.println(elem + "\n");
		}
	}
}
