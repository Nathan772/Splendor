import java.util.HashMap;

public interface TypePartie {

}
